import 'babel-core/register.js';
import config  from './config.json' assert {type: 'json'};

export default config;